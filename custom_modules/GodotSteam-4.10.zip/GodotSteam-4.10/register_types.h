#ifndef GODOTSTEAM_REGISTER_TYPES_H
#define GODOTSTEAM_REGISTER_TYPES_H

#include "modules/register_module_types.h"

void initialize_godotsteam_module(ModuleInitializationLevel level);
void uninitialize_godotsteam_module(ModuleInitializationLevel level);

#endif